import React, { createContext, useState, useContext, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(() => {
        const storedUser = localStorage.getItem('user');
        return storedUser ? JSON.parse(storedUser) : null;
    });

    // Derived state for authentication status
    const isAuthenticated = !!user;

    const login = (userData) => {
        setUser(userData);
        localStorage.setItem('user', JSON.stringify(userData));
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('user');
    };

    // Optional: Automatically log out user if token/session expires (if applicable)
    useEffect(() => {
        if (user && user.tokenExpiry) {
            const timeout = setTimeout(() => {
                logout();
                alert('Session expired. Please log in again.');
            }, new Date(user.tokenExpiry).getTime() - new Date().getTime());

            return () => clearTimeout(timeout);
        }
    }, [user]);

    return (
        <AuthContext.Provider value={{ user, isAuthenticated, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);

    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }

    return context;
};