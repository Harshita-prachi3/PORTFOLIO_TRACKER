// src/components/auth/Register.js
import React, { useState } from 'react';
import {
    Container,
    Paper,
    TextField,
    Button,
    Typography,
    Box,
    Link
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Register = () => {
    const [userData, setUserData] = useState({
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        fullName: '',
        accountBalance: ''
    });
    const [error, setError] = useState(null); // Added state for error handling
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Check if passwords match
        if (userData.password !== userData.confirmPassword) {
            setError("Passwords don't match!"); // Use error state
            return;
        }

        try {
            // Make the API request
            const response = await axios.post('http://localhost:8080/api/users/register', {
                username: userData.username,
                email: userData.email,
                password: userData.password,
                fullName: userData.fullName,
                accountBalance: parseFloat(userData.accountBalance) // Convert to float
            });

            console.log('Registration successful:', response.data);
            alert('Registration successful!'); // Notify the user
            navigate('/login'); // Redirect to the login page
        } catch (err) {
            console.error('Registration failed:', err);

            // Handle different error scenarios
            if (err.response) {
                setError(err.response.data.message || 'Registration failed. Please try again.');
            } else {
                setError('Server error. Please try again later.');
            }
        }
    };

    return (
        <Container component="main" maxWidth="xs">
            <Paper elevation={6} sx={{ mt: 8, p: 4 }}>
                <Typography component="h1" variant="h5" align="center">
                    Register
                </Typography>
                <Box component="form" onSubmit={handleSubmit} sx={{ mt: 1 }}>
                    {error && ( // Display error messages
                        <Typography color="error" align="center" sx={{ mb: 2 }}>
                            {error}
                        </Typography>
                    )}
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Username"
                        autoFocus
                        value={userData.username}
                        onChange={(e) => setUserData({
                            ...userData,
                            username: e.target.value
                        })}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Full Name"
                        value={userData.fullName}
                        onChange={(e) => setUserData({
                            ...userData,
                            fullName: e.target.value
                        })}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Email"
                        type="email"
                        value={userData.email}
                        onChange={(e) => setUserData({
                            ...userData,
                            email: e.target.value
                        })}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Account Balance"
                        type="number"
                        value={userData.accountBalance}
                        onChange={(e) => setUserData({
                            ...userData,
                            accountBalance: e.target.value
                        })}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Password"
                        type="password"
                        value={userData.password}
                        onChange={(e) => setUserData({
                            ...userData,
                            password: e.target.value
                        })}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Confirm Password"
                        type="password"
                        value={userData.confirmPassword}
                        onChange={(e) => setUserData({
                            ...userData,
                            confirmPassword: e.target.value
                        })}
                    />
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        sx={{ mt: 3, mb: 2 }}
                    >
                        Register
                    </Button>
                    <Link href="/login" variant="body2">
                        {"Already have an account? Sign In"}
                    </Link>
                </Box>
            </Paper>
        </Container>
    );
};

export default Register;