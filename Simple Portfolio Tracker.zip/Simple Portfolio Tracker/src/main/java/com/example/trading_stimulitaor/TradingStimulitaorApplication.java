package com.example.trading_stimulitaor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradingStimulitaorApplication {

    public static void main(String[] args) {
        SpringApplication.run(TradingStimulitaorApplication.class, args);
    }

}
