package com.example.trading_stimulitaor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradingStimulitaorApplicationTests {

    @Test
    void contextLoads() {
    }

}
